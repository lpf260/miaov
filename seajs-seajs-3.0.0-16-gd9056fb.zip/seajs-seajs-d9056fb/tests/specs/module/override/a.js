define('a', [], { name: 'a' });
define('a', [], { name: 'a2' });
