define({ name: 'a' });
